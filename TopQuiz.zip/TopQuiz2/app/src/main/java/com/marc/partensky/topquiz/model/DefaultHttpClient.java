package com.marc.partensky.topquiz.model;

class DefaultHttpClient {
}
